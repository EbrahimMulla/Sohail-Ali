document.getElementById('accept-btn').addEventListener('click', function() {
  document.getElementById('disclaimer-popup').style.display = 'none';
});
