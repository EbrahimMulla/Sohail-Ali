module.exports = {
    plugins: [
        require('postcss-preset-env'),
    ],
};

// "sass": "sass assets/scss/style.scss assets/styles/style.css -w"
// "postcss": "postcss assets/styles/style.css -o assets/styles/style.css -w"